import setuptools
import os
import version_info


def get_stub_file_paths(pkg):
    """
    Retrieves a list of file paths to .pyi files for a given Python stub-only package. File paths will not include the
    root package name, Ex. Deadline/Balancer/__init__.pyi would be returned as Balancer/__init__.pyi .
    :param pkg: name of the stub-only package
    :return: list of stub file paths
    """
    stub_files = []
    for dirname, _, files in os.walk(pkg):
        for file_name in files:
            _, extension = os.path.splitext(file_name)
            if extension.lower() == '.pyi':
                directory_path = os.path.relpath(dirname, pkg)
                stub_file = os.path.join(directory_path, file_name)
                stub_files.append(stub_file)

    return stub_files


setuptools.setup(
    name="deadline-stubs",
    version=version_info.__version__,
    author="Thinkbox Software Inc.",
    author_email="support@thinkboxsoftware.com",
    description="Stub-only package for Deadline's Scripting API.",
    long_description="Stub-only package that provides code completion, type-hinting, and doc popups for the Deadline Scripting API.",
    long_description_content_type="text/markdown",
    url="https://docs.thinkboxsoftware.com/products/deadline/10.0/2_Scripting%20Reference/index.html",
    packages=['Deadline'] + setuptools.find_packages(),
    package_data={'Deadline': get_stub_file_paths('Deadline')}
)